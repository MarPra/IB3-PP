package pp.threads.model;

public interface ITaskObserver {
	public void inform(ITask changed);
}
