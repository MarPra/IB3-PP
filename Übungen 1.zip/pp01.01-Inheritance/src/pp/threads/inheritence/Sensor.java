package pp.threads.inheritence;

public class Sensor extends Thread {
	private final long frequency;
	public Sensor(final long frequency) {
		this.frequency = frequency;
//		start();
	}

	/**
	 * @return the frequency
	 */
	public long getFrequency() {
		return this.frequency;
	}

	protected String reading() {
		return null;
	}

	@Override
	public void run() {
		while (true) {
			System.out.println("reading: " + reading());
			try {
				Thread.sleep(this.frequency);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(final String[] args) {
		final Sensor s = new Sensor(1000);
		s.start();
	}
}
